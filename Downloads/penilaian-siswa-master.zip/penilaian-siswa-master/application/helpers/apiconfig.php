<?php
$token   = "d3353ed42f3f5dc07015d195dc36bb19"; 
$passkey = "sizgib"; 
?>

